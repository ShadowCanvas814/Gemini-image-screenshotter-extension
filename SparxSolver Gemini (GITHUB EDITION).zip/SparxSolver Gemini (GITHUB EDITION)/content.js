let isToggled = true; 

window.addEventListener('keydown', (e) => {
    if (!isToggled || e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    // 'Z' to Solve
    if (e.key.toLowerCase() === 'z') {
        createGeminiWindow("Thinking..."); 
        chrome.runtime.sendMessage({ action: "capture_screen" });
    }
    
    // 'X' to Recall Bookwork
    if (e.key.toLowerCase() === 'x') {
        const lookupCode = prompt("Enter Sparx Code (e.g. 1A):");
        if (lookupCode) {
            chrome.storage.local.get([lookupCode.toUpperCase()], (result) => {
                const saved = result[lookupCode.toUpperCase()];
                createGeminiWindow(saved ? `BOOKWORK ANSWER: ${saved}` : "Code not found in memory.");
            });
        }
    }
});

chrome.runtime.onMessage.addListener((request) => {
    const contentDiv = document.getElementById('gemini-content');
    
    if (request.action === "display_response") {
        if (contentDiv) contentDiv.innerText = request.data;
    } 
    
    if (request.action === "save_and_display") {
        const { code, answer } = request;
        chrome.storage.local.set({ [code.toUpperCase()]: answer }, () => {
            if (contentDiv) contentDiv.innerText = `CODE: ${code}\nANSWER: ${answer}\n\n✅ Saved for Bookwork Check.`;
        });
    }
});

function createGeminiWindow(text) {
    let container = document.getElementById('gemini-overlay');
    if (!container) {
        container = document.createElement('div');
        container.id = 'gemini-overlay';
        container.innerHTML = `
            <div id="gemini-header">
                <span>Gemini Quick-Cap</span>
                <button id="gemini-close">×</button>
            </div>
            <div id="gemini-content">${text}</div>
            <div id="gemini-resizer"></div>
        `;
        document.body.appendChild(container);
        setupInteractions(container);
    } else {
        document.getElementById('gemini-content').innerText = text;
    }
}

function setupInteractions(el) {
    const header = el.querySelector('#gemini-header');
    const closeBtn = el.querySelector('#gemini-close');
    closeBtn.onclick = () => el.remove();

    let isDragging = false;
    header.onmousedown = (e) => {
        isDragging = true;
        let shiftX = e.clientX - el.getBoundingClientRect().left;
        let shiftY = e.clientY - el.getBoundingClientRect().top;
        document.onmousemove = (e) => {
            if (!isDragging) return;
            el.style.left = e.pageX - shiftX + 'px';
            el.style.top = e.pageY - shiftY + 'px';
        };
        document.onmouseup = () => {
            isDragging = false;
            document.onmousemove = null;
        };
    };
}