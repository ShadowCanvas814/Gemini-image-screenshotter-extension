async function sendToGemini(base64Image, tabId) {
    const data = await chrome.storage.local.get('gemini_api_key');
    const API_KEY = data.gemini_api_key;

    if (!API_KEY) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "❌ No API Key! Right-click icon -> Options." });
        return;
    }

    // Using the 2.5 Flash-Lite model as requested
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${API_KEY}`;

    try {
        const imageData = base64Image.split(',')[1];
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: "Solve this Sparx problem. Identify the Question Code. Return ONLY a JSON object: {'code': '1A', 'answer': 'your_answer'}." },
                        { inline_data: { mime_type: "image/png", data: imageData } }
                    ]
                }]
            })
        });

        const json = await response.json();
        if (json.candidates && json.candidates[0]?.content?.parts?.[0]?.text) {
            const rawText = json.candidates[0].content.parts[0].text;
            const cleanJson = rawText.replace(/```json|```/g, "").trim();
            const result = JSON.parse(cleanJson);
            
            chrome.tabs.sendMessage(tabId, { 
                action: "save_and_display", 
                code: result.code, 
                answer: result.answer 
            });
        } else {
            chrome.tabs.sendMessage(tabId, { action: "display_response", data: "API Error: Check your key or site access." });
        }
    } catch (err) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "Error: " + err.message });
    }
}

chrome.runtime.onMessage.addListener((request, sender) => {
    if (request.action === "capture_screen") {
        chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" }, (dataUrl) => {
            sendToGemini(dataUrl, sender.tab.id);
        });
    }
});