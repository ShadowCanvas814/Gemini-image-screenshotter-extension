let isToggled = true; 

// 1. Key Listeners
window.addEventListener('keydown', (e) => {
    // Ignore if typing in an input box
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    const key = e.key.toLowerCase();
    const container = document.getElementById('gemini-overlay');

    // 'Z' to Solve
    if (isToggled && key === 'z') {
        createGeminiWindow("Thinking..."); 
        chrome.runtime.sendMessage({ action: "capture_screen" });
    }
    
    // 'X' to Recall Bookwork
    if (isToggled && key === 'x') {
        const lookupCode = prompt("Enter Sparx Code (e.g. 1A):");
        if (lookupCode) {
            chrome.storage.local.get([lookupCode.toUpperCase()], (result) => {
                const saved = result[lookupCode.toUpperCase()];
                createGeminiWindow(saved ? `BOOKWORK ANSWER: ${saved}` : "Code not found in memory.");
            });
        }
    }

    // STEALTH MODE: 'H' to Hide
    if (key === 'h' && container) {
        container.style.display = 'none';
    }

    // STEALTH MODE: 'A' to Appear
    if (key === 'a' && container) {
        container.style.display = 'flex';
    }
});

// 2. Listen for messages from background.js
chrome.runtime.onMessage.addListener((request) => {
    const contentDiv = document.getElementById('gemini-content');
    
    if (request.action === "display_response") {
        if (contentDiv) contentDiv.innerText = request.data;
    } 
    
    if (request.action === "save_and_display") {
        const { code, answer } = request;
        chrome.storage.local.set({ [code.toUpperCase()]: answer }, () => {
            if (contentDiv) contentDiv.innerText = `CODE: ${code}\nANSWER: ${answer}\n\n✅ Saved for Bookwork Check.`;
        });
    }
});

// 3. UI Creation Function
function createGeminiWindow(text) {
    let container = document.getElementById('gemini-overlay');
    if (!container) {
        container = document.createElement('div');
        container.id = 'gemini-overlay';
        container.innerHTML = `
            <div id="gemini-header">
                <span>SparxAI</span>
                <button id="gemini-close">×</button>
            </div>
            <div id="gemini-content">${text}</div>
            <div id="gemini-resizer"></div>
        `;
        document.body.appendChild(container);
        setupInteractions(container);
    } else {
        // Auto-show if hidden when a new result comes in
        container.style.display = 'flex';
        document.getElementById('gemini-content').innerText = text;
    }
}

// 4. Dragging & Closing Logic
function setupInteractions(el) {
    const header = el.querySelector('#gemini-header');
    const closeBtn = el.querySelector('#gemini-close');
    closeBtn.onclick = () => el.remove();

    let isDragging = false;
    header.onmousedown = (e) => {
        isDragging = true;
        let shiftX = e.clientX - el.getBoundingClientRect().left;
        let shiftY = e.clientY - el.getBoundingClientRect().top;
        document.onmousemove = (e) => {
            if (!isDragging) return;
            el.style.left = e.pageX - shiftX + 'px';
            el.style.top = e.pageY - shiftY + 'px';
        };
        document.onmouseup = () => {
            isDragging = false;
            document.onmousemove = null;
        };
    };
}