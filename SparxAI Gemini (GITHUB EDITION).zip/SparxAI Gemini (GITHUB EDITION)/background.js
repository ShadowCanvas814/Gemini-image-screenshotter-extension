async function sendToGemini(base64Image, tabId, instruction) {
    const data = await chrome.storage.local.get('gemini_api_key');
    const API_KEY = data.gemini_api_key;

    if (!API_KEY) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "❌ No API Key!" });
        return;
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${API_KEY}`;

    try {
        const imageData = base64Image.split(',')[1];
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: instruction },
                        { inline_data: { mime_type: "image/png", data: imageData } }
                    ]
                }]
            })
        });

        const json = await response.json();

        // Processing logic now correctly follows the 'json' definition
        if (json.candidates && json.candidates[0]?.content?.parts?.[0]?.text) {
            const aiResponse = json.candidates[0].content.parts[0].text.trim();
            
            // Extract Code (e.g. 1A) using enhanced regex pattern
            const codeMatch = aiResponse.match(/CODE:\s*([0-9]{1,2}[A-Z])/i) || aiResponse.match(/\b([0-9]{1,2}[A-Z])\b/);
            const foundCode = codeMatch ? codeMatch[1] : "N/A";
            
            // Extract the final answer by prioritizing the "ANSWER:" tag
            const answerMatch = aiResponse.match(/ANSWER:\s*(.*)/i);
            let cleanAnswer = answerMatch 
                ? answerMatch[1].trim() 
                : aiResponse.replace(/CODE:.*\|/i, "").replace(/ANSWER:/i, "").trim();

            chrome.tabs.sendMessage(tabId, { 
                action: "save_and_display", 
                code: foundCode, 
                answer: cleanAnswer 
            });
        }
    } catch (err) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "Error: " + err.message });
    }
}

chrome.runtime.onMessage.addListener((request, sender) => {
    if (request.action === "capture_screen") {
        chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" }, (dataUrl) => {
            sendToGemini(dataUrl, sender.tab.id, request.instruction);
        });
    }
});