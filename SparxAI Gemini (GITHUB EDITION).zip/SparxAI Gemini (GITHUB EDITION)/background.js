async function sendToGemini(base64Image, tabId, instruction) {
    // Get both the API key AND the selected model
    const data = await chrome.storage.local.get(['gemini_api_key', 'gemini_model']);
    const API_KEY = data.gemini_api_key;
    const MODEL = data.gemini_model || "gemini-2.5-flash-lite"; // Default fallback

    if (!API_KEY) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "❌ No API Key!" });
        return;
    }

    // URL now uses the dynamic model variable
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${API_KEY}`;

    try {
        const imageData = base64Image.split(',')[1];
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: instruction },
                        { inline_data: { mime_type: "image/png", data: imageData } }
                    ]
                }]
            })
        });

        const json = await response.json();

        if (json.candidates && json.candidates[0]?.content?.parts?.[0]?.text) {
            const aiResponse = json.candidates[0].content.parts[0].text.trim();
            const codeMatch = aiResponse.match(/CODE:\s*([0-9]{1,2}[A-Z])/i) || aiResponse.match(/\b([0-9]{1,2}[A-Z])\b/);
            const foundCode = codeMatch ? codeMatch[1] : "N/A";
            
            const answerMatch = aiResponse.match(/ANSWER:\s*(.*)/i);
            let cleanAnswer = answerMatch 
                ? answerMatch[1].trim() 
                : aiResponse.replace(/CODE:.*\|/i, "").replace(/ANSWER:/i, "").trim();

            chrome.tabs.sendMessage(tabId, { 
                action: "save_and_display", 
                code: foundCode, 
                answer: cleanAnswer 
            });
        }
    } catch (err) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "Error: " + err.message });
    }
}
// ... rest of background.js remains the same ...

chrome.runtime.onMessage.addListener((request, sender) => {
    if (request.action === "capture_screen") {
        chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" }, (dataUrl) => {
            sendToGemini(dataUrl, sender.tab.id, request.instruction);
        });
    }
});