async function sendToGemini(base64Image, tabId, instruction) {
    const data = await chrome.storage.local.get(['gemini_api_key', 'gemini_model']);
    const API_KEY = data.gemini_api_key;
    const MODEL = data.gemini_model || "gemini-1.5-flash"; 

    if (!API_KEY) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "❌ No API Key!" });
        return;
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${API_KEY}`;

    try {
        const imageData = base64Image.split(',')[1];
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: instruction },
                        { inline_data: { mime_type: "image/png", data: imageData } }
                    ]
                }]
            })
        });

        const json = await response.json();
        if (json.candidates && json.candidates[0]?.content?.parts?.[0]?.text) {
            const aiResponse = json.candidates[0].content.parts[0].text.trim();
            
            // IMPROVED REGEX: Specifically looks for Sparx Bookwork codes (e.g., 1A, 24C)
            const codeMatch = aiResponse.match(/CODE:\s*([0-9]{1,3}[A-Z])/i) || aiResponse.match(/\b([0-9]{1,3}[A-Z])\b/i);
            const foundCode = codeMatch ? codeMatch[1].toUpperCase() : "N/A";
            
            // CLEANER ANSWER EXTRACTION
            const answerMatch = aiResponse.match(/ANSWER:\s*([\s\S]*)/i);
            let cleanAnswer = answerMatch ? answerMatch[1].trim() : aiResponse.replace(/CODE:.*\s*/i, "").trim();

            // ALWAYS send back the code and answer separately for the content script to handle
            chrome.tabs.sendMessage(tabId, { 
                action: "save_and_display", 
                code: foundCode, 
                answer: cleanAnswer 
            });
        }
    } catch (err) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "Error: " + err.message });
    }
}

chrome.runtime.onMessage.addListener((request, sender) => {
    if (request.action === "capture_screen") {
        chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" }, (dataUrl) => {
            sendToGemini(dataUrl, sender.tab.id, request.instruction);
        });
    }
});

chrome.tabs.onActivated.addListener(activeInfo => {
    chrome.scripting.executeScript({
        target: { tabId: activeInfo.tabId },
        func: () => { console.log("SparxAI: Tab Active. Ghost timer holding focus."); }
    }).catch(() => {});
});