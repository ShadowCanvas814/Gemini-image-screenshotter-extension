const MODELS = [
    { id: "gemini-2.5-flash-lite", name: "Gemini 2.5 Flash Lite", desc: "Recommended for faster operation" },
    { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro", desc: "Smarter, but slower performance" },
    { id: "gemini-3.1-pro", name: "Gemini 3.1 Pro", desc: "Ultra smart / Experimental" }
];

const modelSelect = document.getElementById('modelSelect');

// Populate the dropdown
MODELS.forEach(m => {
    const opt = document.createElement('option');
    opt.value = m.id;
    opt.innerHTML = `${m.name} (${m.desc})`;
    modelSelect.appendChild(opt);
});

document.getElementById('save').onclick = () => {
    const key = document.getElementById('apiKey').value;
    const isEnabled = document.getElementById('controlsToggle').checked;
    const selectedModel = modelSelect.value;

    chrome.storage.local.set({ 
        gemini_api_key: key,
        controls_enabled: isEnabled,
        gemini_model: selectedModel
    }, () => {
        const status = document.getElementById('status');
        status.innerText = "Saved! Refresh Sparx to use.";
        setTimeout(() => { status.innerText = ""; }, 3000);
    });
};

chrome.storage.local.get(['gemini_api_key', 'controls_enabled', 'gemini_model'], (data) => {
    if (data.gemini_api_key) document.getElementById('apiKey').value = data.gemini_api_key;
    document.getElementById('controlsToggle').checked = data.controls_enabled !== false;
    if (data.gemini_model) modelSelect.value = data.gemini_model;
});