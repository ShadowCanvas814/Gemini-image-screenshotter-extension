document.getElementById('save').onclick = () => {
    const key = document.getElementById('apiKey').value;
    const isEnabled = document.getElementById('controlsToggle').checked;

    chrome.storage.local.set({ 
        gemini_api_key: key,
        controls_enabled: isEnabled 
    }, () => {
        const status = document.getElementById('status');
        status.innerText = "Saved! Refresh Sparx to use.";
        setTimeout(() => { status.innerText = ""; }, 3000);
    });
};

chrome.storage.local.get(['gemini_api_key', 'controls_enabled'], (data) => {
    if (data.gemini_api_key) document.getElementById('apiKey').value = data.gemini_api_key;
    document.getElementById('controlsToggle').checked = data.controls_enabled !== false;
});