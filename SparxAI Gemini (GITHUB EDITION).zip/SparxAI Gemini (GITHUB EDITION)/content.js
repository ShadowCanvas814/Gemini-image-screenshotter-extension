let isToggled = true; 
const isMaths = window.location.hostname.includes('maths');
const isScience = window.location.hostname.includes('science');

// Set the Title based on the site
const extensionName = isMaths ? "SparxMathsAI" : "SparxScienceAI";

// 1. Key Listeners
window.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    const key = e.key.toLowerCase();
    const container = document.getElementById('gemini-overlay');

    // 'Z' to Solve (Both Sites)
    if (isToggled && key === 'z') {
        createGeminiWindow("Thinking..."); 
        chrome.runtime.sendMessage({ action: "capture_screen" });
    }
    
    // 'X' to Recall Bookwork (ONLY Maths)
    if (isMaths && isToggled && key === 'x') {
        const lookupCode = prompt("Enter Sparx Code (e.g. 1A):");
        if (lookupCode) {
            chrome.storage.local.get([lookupCode.toUpperCase()], (result) => {
                const saved = result[lookupCode.toUpperCase()];
                createGeminiWindow(saved ? `BOOKWORK ANSWER: ${saved}` : "Code not found in memory.");
            });
        }
    }

    // Stealth Controls
    if (key === 'h' && container) container.style.display = 'none';
    if (key === 'a' && container) container.style.display = 'flex';
});

// 2. Message Listener
chrome.runtime.onMessage.addListener((request) => {
    const contentDiv = document.getElementById('gemini-content');
    
    if (request.action === "display_response") {
        if (contentDiv) contentDiv.innerText = request.data;
    } 
    
    if (request.action === "save_and_display") {
        const { code, answer } = request;
        
        if (isMaths) {
            // Maths Logic: Save and show code
            chrome.storage.local.set({ [code.toUpperCase()]: answer }, () => {
                if (contentDiv) contentDiv.innerText = `CODE: ${code}\nANSWER: ${answer}\n\n✅ Saved for Bookwork Check.`;
            });
        } else {
            // Science Logic: Just show answer, no saving
            if (contentDiv) contentDiv.innerText = `ANSWER: ${answer}`;
        }
    }
});

// 3. UI Creation
function createGeminiWindow(text) {
    let container = document.getElementById('gemini-overlay');
    if (!container) {
        container = document.createElement('div');
        container.id = 'gemini-overlay';
        container.innerHTML = `
            <div id=\"gemini-header\">
                <span>${extensionName}</span>
                <button id=\"gemini-close\">×</button>
            </div>
            <div id=\"gemini-content\">${text}</div>
            <div id=\"gemini-resizer\"></div>
        `;
        document.body.appendChild(container);
        setupInteractions(container);
    } else {
        container.style.display = 'flex';
        document.getElementById('gemini-content').innerText = text;
    }
}

// 4. Dragging Logic
function setupInteractions(el) {
    const header = el.querySelector('#gemini-header');
    const closeBtn = el.querySelector('#gemini-close');
    closeBtn.onclick = () => el.remove();
    let isDragging = false;
    header.onmousedown = (e) => {
        isDragging = true;
        let shiftX = e.clientX - el.getBoundingClientRect().left;
        let shiftY = e.clientY - el.getBoundingClientRect().top;
        document.onmousemove = (e) => {
            if (!isDragging) return;
            el.style.left = e.pageX - shiftX + 'px';
            el.style.top = e.pageY - shiftY + 'px';
        };
        document.onmouseup = () => {
            isDragging = false;
            document.onmousemove = null;
        };
    };
}