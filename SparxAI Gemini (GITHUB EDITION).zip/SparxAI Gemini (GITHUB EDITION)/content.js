const isMaths = window.location.hostname.includes('maths');
const extensionName = isMaths ? "SparxMathsAI" : "SparxScienceAI";

// Keep a local copy of the toggle state for instant access
let controlsEnabled = true;

// Load the state immediately when the page loads
chrome.storage.local.get('controls_enabled', (data) => {
    controlsEnabled = data.controls_enabled !== false;
});

// Update the local state instantly if the user changes it in options
chrome.storage.onChanged.addListener((changes) => {
    if (changes.controls_enabled) {
        controlsEnabled = changes.controls_enabled.newValue !== false;
    }
});

window.addEventListener('keydown', (e) => {
    // 1. Safety checks
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    if (!controlsEnabled) return; 

    const key = e.key.toLowerCase();
    const container = document.getElementById('gemini-overlay');

    // 2. Control Logic
    if (key === 'z') {
        createGeminiWindow("Solving..."); 
        let prompt = isMaths 
            ? "Identify the Sparx Code and solve. Return 'CODE: [Code] | ANSWER: [Value]'. No sentences."
            : "Solve this. Return ONLY the answer with units. One line only.";
        
        chrome.runtime.sendMessage({ action: "capture_screen", instruction: prompt });
    }
    
    if (isMaths && key === 'x') {
        const lookupCode = prompt("Enter Sparx Code (e.g. 1A):");
        if (lookupCode) {
            chrome.storage.local.get([lookupCode.toUpperCase()], (result) => {
                const saved = result[lookupCode.toUpperCase()];
                createGeminiWindow(saved ? `RECALLED: ${saved}` : "Not found.");
            });
        }
    }

    if (key === 'h' && container) container.style.display = 'none';
    if (key === 'a' && container) container.style.display = 'flex';
});

// Listener for the AI response
chrome.runtime.onMessage.addListener((request) => {
    const contentDiv = document.getElementById('gemini-content');
    if (!contentDiv) return;

    if (request.action === "save_and_display") {
        const { code, answer } = request;
        if (isMaths && code !== "N/A") {
            chrome.storage.local.set({ [code.toUpperCase()]: answer });
            contentDiv.innerHTML = `<span style="color:#00FF00">CODE: ${code}</span><br><span style="color:#00FF00">ANSWER: ${answer}</span>`;
        } else {
            contentDiv.innerText = answer;
        }
    } else if (request.action === "display_response") {
        contentDiv.innerText = request.data;
    }
});

function createGeminiWindow(text) {
    let container = document.getElementById('gemini-overlay');
    if (!container) {
        container = document.createElement('div');
        container.id = 'gemini-overlay';
        container.innerHTML = `
            <div id="gemini-header">
                <span>${extensionName}</span>
                <button id="gemini-close" style="background:none; border:none; color:white; cursor:pointer; font-size:16px;">×</button>
            </div>
            <div id="gemini-content" style="color:#00FF00; font-family:monospace; font-weight:bold;">${text}</div>
        `;
        document.body.appendChild(container);
        setupInteractions(container);
    } else {
        container.style.display = 'flex';
        document.getElementById('gemini-content').innerText = text;
    }
}

function setupInteractions(el) {
    const header = el.querySelector('#gemini-header');
    el.querySelector('#gemini-close').onclick = () => el.style.display = 'none';
    let isDragging = false;
    header.onmousedown = (e) => {
        isDragging = true;
        let shiftX = e.clientX - el.getBoundingClientRect().left;
        let shiftY = e.clientY - el.getBoundingClientRect().top;
        document.onmousemove = (e) => {
            if (!isDragging) return;
            el.style.left = e.pageX - shiftX + 'px';
            el.style.top = e.pageY - shiftY + 'px';
        };
        document.onmouseup = () => { isDragging = false; document.onmousemove = null; };
    };
}