const hostname = window.location.hostname;
let platform = "GeneralAI";

if (hostname.includes('maths.sparx')) platform = "SparxMaths";
else if (hostname.includes('science.sparx')) platform = "SparxScience";
else if (hostname.includes('reader.sparx')) platform = "SparxReader";
else if (hostname.includes('senecalearning')) platform = "SenAI";
else if (hostname.includes('solverx')) platform = "SolverX";

const extensionName = platform + "AI";
let controlsEnabled = true;

function startGhostTimer() {
    setInterval(() => {
        window.dispatchEvent(new MouseEvent('mousemove', {
            view: window, bubbles: true, cancelable: true
        }));
    }, 30000); 
}
startGhostTimer();

chrome.storage.local.get('controls_enabled', (data) => {
    controlsEnabled = data.controls_enabled !== false;
});

chrome.storage.onChanged.addListener((changes) => {
    if (changes.controls_enabled) controlsEnabled = changes.controls_enabled.newValue !== false;
});

window.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    if (!controlsEnabled) return; 

    const key = e.key.toLowerCase();
    const container = document.getElementById('gemini-overlay');

    if (key === 'z') {
        createGeminiWindow("Analyzing Screen..."); 
        let prompt = "";
        switch(platform) {
            case "SparxMaths": prompt = "Solve. MUST include 'CODE: [Code]' (e.g. 1A) and 'ANSWER: [Value]'."; break;
            case "SparxReader": prompt = "Read text. Provide 'ANSWER: [Text]'."; break;
            case "SenAI": prompt = "Identify the correct option. Provide 'ANSWER: [Value]'."; break;
            default: prompt = "Solve and provide 'ANSWER: [Value]'.";
        }
        chrome.runtime.sendMessage({ action: "capture_screen", instruction: prompt });
    }
    
    if (key === 'x') {
        const lookupCode = prompt("Enter Bookwork Code (e.g. 1A):");
        if (lookupCode) {
            const cleanCode = lookupCode.toUpperCase().trim();
            chrome.storage.local.get([cleanCode], (result) => {
                const saved = result[cleanCode];
                createGeminiWindow(saved ? `RECALLED [${cleanCode}]:\n${saved}` : `No answer saved for ${cleanCode}`);
            });
        }
    }

    if (key === 'h' && container) container.style.display = 'none';
    if (key === 'a') {
        if (container) container.style.display = 'flex';
        else createGeminiWindow(extensionName + " Ready. Press Z to Solve.");
    }
});

chrome.runtime.onMessage.addListener((request) => {
    const contentDiv = document.getElementById('gemini-content');
    if (!contentDiv) return;

    if (request.action === "save_and_display") {
        const { code, answer } = request;
        
        // FIX: Using [code] allows dynamic keys like "1A", "2B"
        if (code !== "N/A") {
            chrome.storage.local.set({ [code]: answer }, () => {
                console.log(`Saved ${code}: ${answer}`);
            });
            contentDiv.innerHTML = `<span style="color:#00FF00; border-bottom:1px solid #00FF00;">CODE: ${code}</span><br><br>${answer}`;
        } else {
            contentDiv.innerText = answer;
        }
    } else if (request.action === "display_response") {
        contentDiv.innerText = request.data;
    }
});

function createGeminiWindow(text) {
    let container = document.getElementById('gemini-overlay');
    if (!container) {
        container = document.createElement('div');
        container.id = 'gemini-overlay';
        container.innerHTML = `
            <div id=\"gemini-header\">
                <span>${extensionName}</span>
                <button id=\"gemini-close\">×</button>
            </div>
            <div id=\"gemini-content\">${text}</div>
        `;
        document.body.appendChild(container);
        setupInteractions(container);
    } else {
        container.style.display = 'flex';
        document.getElementById('gemini-content').innerText = text;
    }
}

function setupInteractions(el) {
    const header = el.querySelector('#gemini-header');
    el.querySelector('#gemini-close').onclick = () => el.style.display = 'none';
    let isDragging = false;
    header.onmousedown = (e) => {
        isDragging = true;
        let shiftX = e.clientX - el.getBoundingClientRect().left;
        let shiftY = e.clientY - el.getBoundingClientRect().top;
        document.onmousemove = (e) => {
            if (!isDragging) return;
            el.style.left = e.pageX - shiftX + 'px';
            el.style.top = e.pageY - shiftY + 'px';
        };
        document.onmouseup = () => { isDragging = false; document.onmousemove = null; };
    };
}